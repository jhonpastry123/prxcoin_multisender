const testMode = false;

let web3;
let web3Modal;
let provider;
let selectedAccount;

let multiSenderAddress = testMode ? "0x1Da6636e64c0028C56859201ae29aF4209978004" : "0xb108c55ef912f153e9c117266b88d6b36f7dc5e1";

