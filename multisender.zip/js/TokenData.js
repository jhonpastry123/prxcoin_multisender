var tokenData = 
[
    {
        name: "PRX",
        address: "0x71238884764fc000e35456e285d888080dbef2b0",
        symbol: "18",
        chain: "56"
    },
    {
        name: "BNB",
        address: "0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c",
        symbol: "18",
        chain: "56"
    },
    {
        name: "USDT",
        address: "0x55d398326f99059ff775485246999027b3197955",
        symbol: "18",
        chain: "56"
    }
];

